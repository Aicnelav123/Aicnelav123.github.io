LUIS ADRIAN S. VALENCIA — ONLINE PORTFOLIO

CONTENTS
- index.html: portfolio website
- assets/technology-background.jpg: selected technology background
- assets/mothermade-project.png: MOTHERMADE website screenshot
- assets/Luis-Adrian-Valencia-Resume.pdf: resume PDF opened by the Resume button

HOW TO VIEW
1. Extract the ZIP file.
2. Open index.html in a web browser.
3. Keep the assets folder beside index.html.

RESUME
Click "Open Resume PDF" in the Resume section to open the supplied PDF in a new browser tab.

CONTACT FORM
The Gmail-style contact form has To, From, Subject, and Message fields. Send opens the visitor's email application using a mailto link; it does not send or store messages directly on the website.

PUBLISHING
To make the site publicly accessible, upload the extracted folder to a static website host such as GitHub Pages or Netlify.
